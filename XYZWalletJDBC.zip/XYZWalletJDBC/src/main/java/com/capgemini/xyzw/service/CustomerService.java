package com.capgemini.xyzw.service;

import java.util.ArrayList;

import com.capgemini.xyz.dao.CustomerDao;
import com.capgemini.xyzw.bean.CustomerBean;
import com.capgemini.xyzw.bean.Transaction;

public class CustomerService implements InterfaceCustomerService{
	
	static String namePattern="[a-zA-Z]{1,}[\\s][a-zA-Z]{1,}|[a-zA-Z]{1,}";
	static String contactPattern="[0-9]{10}";
	static String emailIDPattern="[a-zA-Z0-9#!'+-?={$%}^&*._()]{1,}[@]{1}[a-zA-Z.]{1,}";
	static String passwordPattern="[a-zA-Z0-9_!#@]{8,16}";

	
	CustomerDao dao;
	public CustomerService()
	{
		dao=new CustomerDao();
	}

	public boolean validateName(String name)
	{  boolean flag1=false;
		if(name.matches(namePattern))
		{
			flag1=true;
		}
		return flag1;	
	}

	 public boolean validatePassword(String password)
	 {boolean flag4=false;
	 if(password.matches(passwordPattern))
		{
			flag4=true;
		}
		return flag4;
	 
	 }
	public boolean validateContactNumber(String contactNo) {
		// TODO Auto-generated method stub
		boolean flag2=false;
		if(contactNo.matches(contactPattern))
		{
			flag2=true;
		
		}return flag2;
	}


	public boolean validateEmailID(String emailID) {
		// TODO Auto-generated method stub
		boolean flag3=false;
		if(emailID.matches(emailIDPattern))
		{
			flag3=true;
		
		}return flag3;
	}


	public double showBalance(int userpin) {
		// TODO Auto-generated method stub
		return dao.showBalance(userpin);
	}

	public CustomerBean addDetailsToDB(CustomerBean bean) {
		// TODO Auto-generated method stub
		return dao.addDetails(bean);
	}

	public double withdrawAmount(int userpin, double amt) {
		// TODO Auto-generated method stub
		return dao.withdrawAmount(userpin, amt);
	}

	public double depositAmount(int userpin, double amt) {
		// TODO Auto-generated method stub
		return dao.depositAmount(userpin,amt);
	}

	public boolean validateLogin(String userName, String password) {
		// TODO Auto-generated method stub
		return dao.validateLogin(userName,password);
	}

	public CustomerBean moneyTransfer(String receiverName,int pin, double amt1) {
		// TODO Auto-generated method stub
		return dao.moneyTransfer(receiverName,pin,amt1);
	}

	public ArrayList<Transaction> printTransactions(int pin) {
		// TODO Auto-generated method stub
		return dao.printTransactions(pin);
	}

}
