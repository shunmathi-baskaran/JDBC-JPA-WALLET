package com.capgemini.xyzw.bean;

import java.util.ArrayList;

public class CustomerBean
{
	private String userName,password,emailID, contactNo;
    private long accountNo;
	private int pinNo;
	private double balance;
	public ArrayList<Transaction> getTrans() {
		return trans;
	}
	public void setTrans(ArrayList<Transaction> trans) {
		this.trans = trans;
	}
	private ArrayList<Transaction> trans;
	
	public long getAccountNo() {
		return accountNo;
	}
	public void setAccountNo(long accountNo) {
		this.accountNo = accountNo;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getEmailID() {
		return emailID;
	}
	public void setEmailID(String emailID) {
		this.emailID = emailID;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getContactNo() {
		return contactNo;
	}
	public void setContactNo(String contactNo) {
		this.contactNo = contactNo;
	}
	public int getPinNo() {
		return pinNo;
	}
	public void setPinNo(int pin) {
		this.pinNo = pin;
	}
	
	public void setBalance(double i) {
		// TODO Auto-generated method stub
      balance=i;
	}
	public double getBalance() {
		return balance;
	}
	@Override
	public String toString() {
		return "CustomerBean [userName=" + userName + ", password=" + password + ", emailID=" + emailID + ", contactNo="
				+ contactNo + ", accountNo=" + accountNo + ", pinNo=" + pinNo + ", balance=" + balance + "]";
	}
	

	
}
