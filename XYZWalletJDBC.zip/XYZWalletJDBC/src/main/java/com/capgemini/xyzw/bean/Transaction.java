package com.capgemini.xyzw.bean;

public class Transaction {

	private String description;
	private String userName;
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getUserName() {
		return userName;
	}
	
	public void setUserName(String userName) {
		this.userName = userName;
	}
	@Override
	public String toString() {
		return "[User name="+userName+"\tdescription=" + description+"]";
	}
	
	
}
