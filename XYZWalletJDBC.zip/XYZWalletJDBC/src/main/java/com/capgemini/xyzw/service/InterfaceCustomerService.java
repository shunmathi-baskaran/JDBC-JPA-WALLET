package com.capgemini.xyzw.service;

import com.capgemini.xyzw.bean.CustomerBean;

public interface InterfaceCustomerService {

	double showBalance(int userpin);
	CustomerBean addDetailsToDB(CustomerBean bean);
	double withdrawAmount(int userpin, double amt);
	double depositAmount(int userpin, double amt);
}
