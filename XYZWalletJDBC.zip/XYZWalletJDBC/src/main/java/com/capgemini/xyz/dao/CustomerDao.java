package com.capgemini.xyz.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import com.capgemini.xyzw.bean.CustomerBean;
import com.capgemini.xyzw.bean.Transaction;
import com.capgemini.xyzw.util.DBUtil;

public class CustomerDao implements InterfaceCustomerDao {
	
CustomerBean bean;
Connection con;
public CustomerDao()
{
	con=DBUtil.getConnect();
	bean=new CustomerBean();
	
}
	
	public CustomerBean addDetails(CustomerBean bean) {
		CustomerBean ref=null;
		String sql="INSERT INTO BankCustomer VALUES(?,?,?,?,?,?,?)";
	try{
		PreparedStatement pstmt=con.prepareStatement(sql);
		pstmt.setInt(1,bean.getPinNo());
		pstmt.setString(2,bean.getUserName());
		pstmt.setString(3,bean.getPassword());
		pstmt.setString(4,bean.getContactNo());
		pstmt.setString(5,bean.getEmailID());
		pstmt.setLong(6,bean.getAccountNo());
		pstmt.setDouble(7,bean.getBalance());
		
		int row=pstmt.executeUpdate();
		if(row>0){
			System.out.println("Successfully inserted record");
			
			ref=bean;
			
		}else 
			ref=null;
		}
	catch(Exception e)
	{
		System.out.println(e.getMessage());
	}
	return ref;
	}
		
	public double showBalance(int userpin) {
		// TODO Auto-generated method stub
		String sql="SELECT balance FROM BankCustomer WHERE pinNo=?";
		double bal=0;
		try {
			PreparedStatement pstmt=con.prepareStatement(sql);
			pstmt.setInt(1,userpin);
			ResultSet rs=pstmt.executeQuery();
			if(rs.next())
			{
				bal=rs.getDouble(1);
			}
	
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return bal;
	}

	public double withdrawAmount(int userpin, double amt) {
		// TODO Auto-generated method stub
		String sql="SELECT balance FROM BankCustomer WHERE pinNo=?";
	double balW=0;
		try {
			PreparedStatement pstmt=con.prepareStatement(sql);
			pstmt.setInt(1,userpin);
			ResultSet rs=pstmt.executeQuery();
			if(rs.next())
			{
				
			  balW=rs.getDouble(1);
			if(balW>=amt)
			{
				balW=balW-amt;
				bean.setBalance(balW);
				String sqlW="UPDATE BankCustomer SET balance=? WHERE pinNo=?";
				PreparedStatement pstmtW=con.prepareStatement(sqlW);
				pstmtW.setInt(2, bean.getPinNo());	
				pstmtW.setDouble(1, bean.getBalance());
				int a=pstmtW.executeUpdate();
			}
			
			else
				System.out.println("withdrawal cannot be done");
			
			String sql1="INSERT INTO Transaction VALUES(?,?)";
				PreparedStatement pstmt1=con.prepareStatement(sql1);
				pstmt1.setString(1, bean.getUserName());
				String msg="Amount"+amt+"is withdrawed from your account";
				pstmt1.setString(2,msg);
				int rs1=pstmt1.executeUpdate();
		}
			} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return balW;
	}
		
		

	public double depositAmount(int userpin, double amt) {
		// TODO Auto-generated method stub
		String sql="SELECT balance FROM BankCustomer WHERE pinNo=?";
		double balA=0;
		try {
			PreparedStatement pstmt=con.prepareStatement(sql);
			pstmt.setInt(1,userpin);
			ResultSet rs=pstmt.executeQuery();
			if(rs.next())
			{
				balA=rs.getDouble(1)+amt;
				bean.setBalance(balA);
				
				String sqlA="UPDATE BankCustomer SET balance=? WHERE pinNo=?";
				PreparedStatement pstmtA=con.prepareStatement(sqlA);
				pstmtA.setDouble(1, bean.getBalance());
				pstmtA.setInt(2, bean.getPinNo());	
				int a=pstmtA.executeUpdate();
			}
			String sql1="INSERT INTO Transaction VALUES(?,?)";
			PreparedStatement pstmt1=con.prepareStatement(sql1);
			pstmt1.setString(1, bean.getUserName());
			String msg2="Amount"+amt+"is deposited to your account";
			pstmt1.setString(2,msg2);
			int rs1=pstmt1.executeUpdate();
	
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return balA;
	}
	
	public boolean validateLogin(String userName, String password) {
		// TODO Auto-generated method stub
		String sql="SELECT * FROM BankCustomer WHERE userName=? AND password=?";
		boolean flag=false;
		try
		{
			PreparedStatement pstmt=con.prepareStatement(sql);
			pstmt.setString(1,userName);
			pstmt.setString(2, password);
			ResultSet rs=pstmt.executeQuery();
			if(rs.next())
			{   bean.setPinNo(rs.getInt(1));
				bean.setUserName(rs.getString(2));
				bean.setPassword(rs.getString(3));
				bean.setContactNo(rs.getString(4));	
				bean.setEmailID(rs.getString(5));
				bean.setAccountNo(rs.getLong(6));
				bean.setBalance(rs.getDouble(7));
				System.out.println(bean);
				flag=true;
				}
		}catch(Exception e){
			e.printStackTrace();
		}
		return flag;
}

	public CustomerBean moneyTransfer(String receiverName,int pinNo, double amt1) {
		// TODO Auto-generated method stub
		CustomerBean sender=new CustomerBean();
		CustomerBean receiver=new CustomerBean();
		String sql="SELECT * FROM BankCustomer WHERE userName=?";
		try
		{
			PreparedStatement pstmt=con.prepareStatement(sql);
			pstmt.setString(1,receiverName);
			ResultSet rs=pstmt.executeQuery();
			if(rs.next())
			{   receiver.setPinNo(rs.getInt(1));
				receiver.setUserName(rs.getString(2));
				receiver.setPassword(rs.getString(3));
				receiver.setContactNo(rs.getString(4));	
				receiver.setEmailID(rs.getString(5));
				receiver.setAccountNo(rs.getLong(6));
				receiver.setBalance(rs.getDouble(7));
				System.out.println(	receiver);
		     }
				
     String sql1="SELECT * from BankCustomer WHERE pinNo=?";
     try
		{
			PreparedStatement pstmt1=con.prepareStatement(sql1);
			pstmt1.setInt(1,pinNo);
			ResultSet rs1=pstmt1.executeQuery();
			if(rs1.next())
			{   sender.setPinNo(rs1.getInt(1));
			    sender.setUserName(rs1.getString(2));
			    sender.setPassword(rs1.getString(3));
			    sender.setContactNo(rs1.getString(4));	
			    sender.setEmailID(rs1.getString(5));
		    	sender.setAccountNo(rs1.getLong(6));
			    sender.setBalance(rs1.getDouble(7));
				System.out.println(sender);
		     }
			String sql5="UPDATE BankCustomer SET balance=? WHERE pinNo=?";
			PreparedStatement pstmt4=con.prepareStatement(sql5);
			double senderBal=sender.getBalance()-amt1;
			sender.setBalance(senderBal);
			pstmt4.setDouble(1,sender.getBalance());	
			pstmt4.setInt(2,pinNo);	
			int i=pstmt4.executeUpdate();
			
			String sql6="UPDATE BankCustomer SET balance=? WHERE userName=?";
			PreparedStatement pstmt5=con.prepareStatement(sql6);
			double receiverBal=receiver.getBalance()+amt1;
			receiver.setBalance(receiverBal);
			pstmt5.setDouble(1,receiver.getBalance());
			pstmt5.setString(2,receiverName);	
			int j=pstmt5.executeUpdate();
		}
		catch(Exception e){
			e.printStackTrace();
		}
			
			String sql2="INSERT INTO Transaction VALUES(?,?)";
	
			try{
				PreparedStatement pstmt2=con.prepareStatement(sql2);
				pstmt2.setString(1, sender.getUserName());
				String msg3="Amount"+amt1+"is tranferred to "+receiver.getUserName();
				pstmt2.setString(2,msg3);
				int rs2=pstmt2.executeUpdate();
				PreparedStatement pstmt3=con.prepareStatement(sql2);
				pstmt3.setString(1, receiver.getUserName());
				String msg4="Amount"+amt1+"is tranferred from "+sender.getUserName();
				pstmt3.setString(2,msg4);
				int rs3=pstmt3.executeUpdate();
			}
		catch(Exception e){
			e.printStackTrace();
		}
		}
		catch(Exception e){
			e.printStackTrace();
		}
     
		return sender;
		}

	public ArrayList<Transaction> printTransactions(int userpin) {
		// TODO Auto-generated method stub
		
		ArrayList<Transaction> al=new ArrayList<Transaction>();
		 String sql="SELECT userName from BankCustomer WHERE pinNo=?";
		 String sql1="SELECT * from Transaction WHERE Name=?";
	     try
			{
				PreparedStatement pstmt=con.prepareStatement(sql);
				pstmt.setInt(1,userpin);
				ResultSet rs=pstmt.executeQuery();
				if(rs.next())
				{
					PreparedStatement pstmt1=con.prepareStatement(sql1);
				pstmt1.setString(1,rs.getString(1));
				ResultSet rs1=pstmt1.executeQuery();
				while(rs1.next()) {
				 Transaction trans=new Transaction();
				trans.setUserName(rs1.getString(1));
				trans.setDescription(rs1.getString(2));
				al.add(trans);
				}
				}}catch(Exception e) {
					e.getMessage();
				}
return al;
}
}
