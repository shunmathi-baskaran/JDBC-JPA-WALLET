package com.capgemini.ui;

import java.util.ArrayList;
import java.util.Scanner;

import com.capgemini.xyzw.bean.CustomerBean;
import com.capgemini.xyzw.bean.Transaction;
import com.capgemini.xyzw.service.CustomerService;

public class Client {

public static void main(String[] args) {
		
		//declarations
		int choice1,choice2;
		String userName,phoneNumber,emailID,password;
		long accountNo;
		int pinNo;
		double balance;
		boolean flag,flag1,flag2,flag3,flag4,flag5;
	
		Scanner scan=new Scanner(System.in);
		try
		{
			CustomerService service =new CustomerService();
			CustomerBean bean=new CustomerBean(); 

			
		//menu driven loop
		do
		{
			System.out.println("XYZ Wallet");
			System.out.println("1.Sign in");
			System.out.println("2.Log in");
			System.out.println("3.Exit");
			System.out.println("Enter your choice");
			choice1=scan.nextInt();
			
			switch(choice1){
			
			case 1: 
			{ //user name
				do{
				System.out.println("Enter the username");
		        userName=scan.next();
	            flag1=service.validateName(userName);
	           
		        	  if(flag1==false)
		              {
		        	   System.out.println("user name should not contain any numbers or special characters");
		               }
		          }while(flag1==false); 
		          
			//password
				do
				{
					System.out.println("Set your password");
					password=scan.next();
					flag2=service.validatePassword(password);
					if(flag2==false)
					{System.out.println("password should contain atleast 8 characters");
					}
				}while(flag2==false);
		       
		     //email id  
		        do{  
	            System.out.println("Enter the email Id");
	            emailID=scan.next();
	            flag3=service.validateEmailID(emailID);
	            
		        	  if(flag3==false)
		              {
		        	   System.out.println("enter valid email id");
		              }
		           }while(flag3==false); 
		     
		        
		        //phone number
	             do{
		          System.out.println("Enter the phonenumber");
		          phoneNumber=scan.next();
		          flag4=service.validateContactNumber(phoneNumber);
		         
		        	  if(flag4==false)
		              {
		        	   System.out.println("Enter the valid phone number");
		              }
		           }while(flag4==false); 
		        
	             
	           //account number
		          System.out.println("Enter the account number");
		          accountNo=scan.nextLong();
		          
		          
		      //balance
		          System.out.println("Enter the starting balance");
		          balance=scan.nextDouble();
		          
		    
		       //assign to object 
		          double dpin=Math.floor((Math.random()*10000));
		          int pin=(int) dpin;
		        bean.setPinNo(pin);
		  		bean.setUserName(userName);
		  		bean.setPassword(password);
		  		bean.setContactNo(phoneNumber);
		  		bean.setEmailID(emailID);
		  		bean.setAccountNo(accountNo);
		  		bean.setBalance(balance);
		  		
		  		CustomerBean obj=service.addDetailsToDB(bean);
		  		if(bean!=null)
		  		{
		        System.out.println("your account has been created");
		        System.out.println("your pin no is "+obj.getPinNo());
		  		}
		  		else
		  			System.out.println("some problem occured....try again");               
		   	  
                break;
			  }
		
			case 2:
				{ 
					do
					{
						System.out.println("Enter the username");
					    String name = scan.next();
					    System.out.println("Enter the password");
					    String pwd=scan.next();
			            flag=service.validateLogin(name,pwd);
		        	  if(flag==false)
		        	  System.out.println("Enter the valid user name and password");
		             }while(flag==false); 
		          				
					
					do{ 
					//StringBuilder build=new StringBuilder();
				    System.out.println("Enter the operation to perform");
                    System.out.println("1.Check balance");
                    System.out.println("2.Deposit");
                    System.out.println("3.withdraw");
                    System.out.println("4.Fund Transfer");
                    System.out.println("5.Print Transactions");
                    System.out.println("6.Exit");
                    
				    choice2=scan.nextInt();
	          
	               switch(choice2)
                     {     
	               
                  case 1:System.out.println("Enter your pin number");
                         int userpin= scan.nextInt();
                         System.out.println("Your Account balance is:"+service.showBalance(userpin));
                         break;
                         
                  case 2: {
                	        System.out.println("Enter the amount to deposit");
                	        double amt=scan.nextDouble();
                	        System.out.println("Enter your pin number");
                            userpin= scan.nextInt();
                	        double bal=service.depositAmount(userpin,amt);
                	        System.out.println("Balance is"+bal);
                	        break;
                	        
                          }
                  case 3: {
                	        System.out.println("Enter the amount to withdraw");
                	        double amt=scan.nextDouble();
                	        System.out.println("Enter your pin number");
                            userpin= scan.nextInt();
                	        double bal= service.withdrawAmount(userpin, amt);
                	        //System.out.println("Withdrawed successfully");
                	        System.out.println("Balance is"+bal);
                	       
                            break;
                          }
                  
                 case 4: { 
                	        
                            System.out.println("Enter the name of the receiver");
      	                    String receiverName=scan.next();
      	                    System.out.println("Enter the amount to transfer");
      	                    double amt1=scan.nextDouble();
      	                    System.out.println("Enter your pin no");
      	                    int pin=scan.nextInt();
      	                    CustomerBean sender=service.moneyTransfer(receiverName,pin,amt1);
      	                    System.out.println("Amount is successfully transferred to "+receiverName);
      	                    System.out.println("Your account balance is"+sender.getBalance());
      	                    break;
                  }
                	        
                	        
               case 5: {
                	     
                	      System.out.println("Enter the pin number");
                	      int pin=scan.nextInt();
                          ArrayList<Transaction> list=service.printTransactions(pin);
                          if(list.equals(null))
                          System.out.println("No Transactions done");
                          else {
                        	  for (Transaction transaction : list) {
                        		  System.out.println(transaction);}
                          }
                               
                          break;
       	                }
               case 6:  System.out.println("Thank You");
               
				        System.exit(12);
				        break;
			
                  
                            default: System.out.println("Enter the valid choice");   
                     }
                            System.out.println("Do you wish to perform any other operation  1.Yes  2.No");//switch case 1
                            choice2=scan.nextInt();
			     	       }while(choice2==1);
				            break;}//case2
			
			case 3:
				System.out.println("Thank You");
				System.exit(12);
				break;
			
		    default: System.out.println("Enter a valid choice");
			} 
				System.out.println("Do you wish to continue: 1.Yes 2.No");
				choice1=scan.nextInt();
			}while(choice1==1);
		
		}catch(Exception e){
			System.out.println(e.getMessage());
		}
		}


}
