package com.capgemini.xyz.dao;

import java.util.List;

import javax.persistence.*;

import com.capgemini.xyz.bean.CustomerBean;
import com.capgemini.xyz.bean.Transaction;

public class CustomerDao implements InterfaceCustomerDao {
	EntityManagerFactory factory;
	EntityManager em;
	
	public CustomerDao() {
		factory=Persistence.createEntityManagerFactory("hello");
		em=factory.createEntityManager();
	}
	
	@Override
	public CustomerBean addDetails(CustomerBean bean) {
		// TODO Auto-generated method stub
		em.getTransaction().begin();
		em.persist(bean);
		em.getTransaction().commit();
		return bean;
	}
	@Override
	public double showBalance(int userpin) {
		// TODO Auto-generated method stub
	
		CustomerBean bean1=em.find(CustomerBean.class, userpin);
		return bean1.getBalance();
		}
	
	@Override
	public double withdrawAmount(int userpin, double amt) {
		// TODO Auto-generated method stub
		CustomerBean bean2=em.find(CustomerBean.class, userpin);
		double bal=bean2.getBalance();
		if(bal>amt)
		{
			bal=bal-amt;
			bean2.setBalance(bal);
			em.getTransaction().begin();
			em.merge(bean2);
            em.getTransaction().commit();
            Transaction trans=new Transaction();
            trans.setWithdrawedAmount(amt);
            trans.setSenderName(bean2.getUserName());
            trans.setBalance(bal);
            em.getTransaction().begin();
			em.persist(trans);
            em.getTransaction().commit();
            
		return bal;
		}
		else 
		{System.out.println("Not enough balance");
		return bal;
		}
	}

	@Override
	public double depositAmount(int userpin, double amt) {
		// TODO Auto-generated method stub
		CustomerBean bean3=em.find(CustomerBean.class, userpin);
		double bal=bean3.getBalance()+amt;
		bean3.setBalance(bal);
		em.getTransaction().begin();
		em.merge(bean3);
		em.getTransaction().commit();
		Transaction trans=new Transaction();
        trans.setDepositedAmount(amt);
        trans.setSenderName(bean3.getUserName());
        trans.setBalance(bal);
        em.getTransaction().begin();
		em.persist(trans);
        em.getTransaction().commit();
        
		return bal;
	}

	public boolean validateLogin(String userName, String password) {
		// TODO Auto-generated method stub
		
		String qry= "SELECT bean from CustomerBean bean WHERE bean.userName=:unm AND bean.password=:pwd";
		TypedQuery<CustomerBean> tqry =em.createQuery(qry, CustomerBean.class);
		tqry.setParameter("unm",userName);
		tqry.setParameter("pwd",password);
	    CustomerBean b=tqry.getSingleResult();
		if(b.getUserName().equals(userName))
		return true;
		else
		return false;
	}

	public CustomerBean moneyTransfer(String receiverName, int pin, double amt1) {
		// TODO Auto-generated method stub
		String qry= "SELECT bean from CustomerBean bean WHERE bean.userName=:unm";
		TypedQuery<CustomerBean> tqry =em.createQuery(qry, CustomerBean.class);
		tqry.setParameter("unm",receiverName);
	    CustomerBean receiver=tqry.getSingleResult();
	    CustomerBean sender=em.find(CustomerBean.class,pin);
		double senderBal=sender.getBalance();
		if(senderBal>amt1)
		{
			senderBal=senderBal-amt1;
			sender.setBalance(senderBal);
		}
		else
			System.out.println("Not enough balance");
		
		double receiverBal=receiver.getBalance()+amt1;
		receiver.setBalance(receiverBal);
		em.getTransaction().begin();
		em.merge(sender);
		em.merge(receiver);
		em.getTransaction().commit();
		
		Transaction trans=new Transaction();
        trans.setFundTransfered(amt1);
        trans.setSenderName(sender.getUserName());
        trans.setReceiverName(receiverName);
        trans.setReceiverAccount(receiver.getAccountNo());
        trans.setBalance(senderBal);
        em.getTransaction().begin();
		em.persist(trans);
        em.getTransaction().commit();
		return sender;
	}

	public List<Transaction> printTransactions(String name) {
		// TODO Auto-generated method stub
		String qry="SELECT trans FROM Transaction trans WHERE trans.senderName=:name";
		TypedQuery<Transaction> tqry=em.createQuery(qry,Transaction.class);
		tqry.setParameter("name",name);
		List<Transaction> l=tqry.getResultList();
		return l;
	}
	
}
