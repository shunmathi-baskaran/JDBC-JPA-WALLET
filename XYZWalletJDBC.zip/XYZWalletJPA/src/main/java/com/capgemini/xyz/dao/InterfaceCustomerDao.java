package com.capgemini.xyz.dao;

import com.capgemini.xyz.bean.CustomerBean;

public interface InterfaceCustomerDao {


	double showBalance(int userpin);
    CustomerBean addDetails(CustomerBean bean);
	double withdrawAmount(int userpin, double amt);
	double depositAmount(int userpin, double amt);
	
}
