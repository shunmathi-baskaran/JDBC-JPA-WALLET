package com.capgemini.xyz.bean;

import javax.persistence.*;

@Entity
@Table(name="TransactionTable")
public class Transaction {
@Id
@GeneratedValue(strategy=GenerationType.AUTO)
    private int id;
	private String senderName;
	private String receiverName;
	private double depositedAmount;
	private double withdrawedAmount;
	private double fundTransfered;
	private long receiverAccount;
	private double balance;
	@ManyToOne
	@JoinColumn(name="pinNo")
	private CustomerBean beans;

	public String getSenderName() {
		return senderName;
	}
	public void setSenderName(String senderName) {
		this.senderName = senderName;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public CustomerBean getBeans() {
		return beans;
	}
	public void setBeans(CustomerBean beans) {
		this.beans = beans;
	}
	public String getReceiverName() {
		return receiverName;
	}
	public void setReceiverName(String receiverName) {
		this.receiverName = receiverName;
	}
	
	public double getDepositedAmount() {
		return depositedAmount;
	}
	public void setDepositedAmount(double depositedAmount) {
		this.depositedAmount = depositedAmount;
	}
	public double getWithdrawedAmount() {
		return withdrawedAmount;
	}
	public void setWithdrawedAmount(double withdrawedAmount) {
		this.withdrawedAmount = withdrawedAmount;
	}
	public double getFundTransfered() {
		return fundTransfered;
	}
	public void setFundTransfered(double fundTransfered) {
		this.fundTransfered = fundTransfered;
	}
	
	public double getBalance() {
		return balance;
	}
	public void setBalance(double balance) {
		this.balance = balance;
	}
	public long getReceiverAccount() {
		return receiverAccount;
	}
	public void setReceiverAccount(long receiverAccount) {
		this.receiverAccount = receiverAccount;
	}
	@Override
	public String toString() {
		return "Transaction [id=" + id + ", senderName=" + senderName + ", receiverName=" + receiverName
				+ ", depositedAmount=" + depositedAmount + ", withdrawedAmount=" + withdrawedAmount
				+ ", fundTransfered=" + fundTransfered + ", receiverAccount=" + receiverAccount + ", balance=" + balance
				+ "]";
	}
	
	
}
