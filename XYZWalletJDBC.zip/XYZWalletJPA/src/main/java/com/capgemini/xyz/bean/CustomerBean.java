package com.capgemini.xyz.bean;

import java.io.Serializable;
import java.util.List;

import javax.persistence.*;

@Entity
@Table(name="CustomerTable")
public class CustomerBean implements Serializable {
	
	private String userName,password,emailID, contactNo;
    private long accountNo;
    @Id
	private int pinNo;
	private double balance;
    @OneToMany(cascade=CascadeType.ALL,mappedBy="beans",fetch=FetchType.LAZY)
    private List<Transaction> trans;
	
	public long getAccountNo() {
		return accountNo;
	}
	public void setAccountNo(long accountNo) {
		this.accountNo = accountNo;
	}
	public List<Transaction> getTrans() {
		return trans;
	}
	public void setTrans(List<Transaction> trans) {
		this.trans = trans;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getEmailID() {
		return emailID;
	}
	public void setEmailID(String emailID) {
		this.emailID = emailID;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getContactNo() {
		return contactNo;
	}
	public void setContactNo(String contactNo) {
		this.contactNo = contactNo;
	}
	public int getPinNo() {
		return pinNo;
	}
	public void setPinNo(int pin) {
		this.pinNo = pin;
	}
	
	public void setBalance(double i) {
		// TODO Auto-generated method stub
      balance=i;
	}
	public double getBalance() {
		return balance;
	}
	
	

	
}
