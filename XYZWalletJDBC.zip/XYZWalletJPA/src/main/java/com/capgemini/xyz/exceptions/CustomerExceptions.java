package com.capgemini.xyz.exceptions;

public class CustomerExceptions extends Exception {

String message;
	
	public void XYZWalletException(String msg)
	{
		message=msg;
	}
	
	@Override
	public String getMessage()
	{
		return message;
	}
}
